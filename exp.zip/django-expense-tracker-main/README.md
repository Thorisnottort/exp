
### Adding Expenses

You can add an expense by clicking the "Add Expense" button, filling and submitting the expense form.

Once you've added the expense it will be displayed on the total expenses element, the homepage's line chart and will also be listed below on the expenses table.

![Display gif clicking Add Expense button, filling and submitting expense form and displaying expense on line chart and expense table](demo/add-expense-demo.gif)

**Note:**  
_Line chart will only appear if you have 2 or more expenses added._

### Adding Monthly Budget

You can add a monthly budget by clicking the
Add Monthly Budget button, filling and submitting the form.

Once you've added it the budget UI will be displayed, including the budget progress bar, the monthly budget next to the expenses of the current month and the edit and delete buttons.

![Display gif clicking Add Budget button, filling and submitting budget form and displaying the budget UI](demo/add-budget-demo.gif)

### Checking Charts & Statistics

Finally you can access charts and statistics about your expenses by navigating to the Charts & Statistics section.

Here you can find expense charts with amounts grouped by month and week, as well as total and monthly expenses grouped by categories.

You can find your current monthly expenses (with controls for editing or deleting budget here too), as well as last month expenses and statistics like monthly expense average, daily expense average, current vs last month expense percetange difference and more.

![Display gif navigating to Charts & Analytics section](demo/charts-and-analytics-demo.gif)

<br />

### Credentials

username: testuser1  
password: testpass1

<br />

## Installation


And run:

     python -m venv venv

This will install the virtual environments and all dependencies.

Now start the virtual environment shell:

     venv\scripts\activate 

pip install -r requirements.txt



Run migrations:

    python manage.py makemigrations
    python manage.py migrate

Create superuser:

    python manage.py createsuperuser

Now you can start server...

    python manage.py runserver

...and visit http://localhost:8000/


## Uses

- Django.
- Postgres.
- Bootstrap.
- Chart.js.
- Cypress.

## Features

- Expense list.
- Expense charts.
- Monthly budget bar.
- Statistics table.
- Authentication.
- Form validation.
- Pagination.
- UI tests.
- Visual tests.
- Unit tests.
