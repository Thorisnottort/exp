
const kTitle = "KETTIK";
const kHomePageTitle = "Discover";