import 'package:flutter/material.dart';

Color kAccentColor = Color(0XFFFFC107);
Color kPrimaryColor = Colors.white;
Color kAppBarBackground = Color(0XFFFFC107);
Color kComplement = Color(0XFF03658C);
Color ksecond = Color(0XFFE57A44);
